"""
Lambda function triggered by SQS messages.

Each SQS message body must be a JSON object with:
  {
    "bucket_name": "my-bucket",
    "file_name":   "path/to/file.pdf"
  }

The Lambda calls the File Info API and logs the result.
"""

import json
import os
import urllib.request
import urllib.error
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# The API endpoint — override via environment variable
FILE_INFO_API_URL = os.environ.get("FILE_INFO_API_URL", "http://file-info-api:8000")


def call_file_info_api(bucket_name: str, file_name: str) -> dict:
    """Call the File Info API and return parsed JSON response."""
    url = f"{FILE_INFO_API_URL}/file-info"
    payload = json.dumps({"bucket_name": bucket_name, "file_name": file_name}).encode()

    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode()
            data = json.loads(body)
            logger.info("API response: %s", json.dumps(data))
            return {"status": "success", "data": data}
    except urllib.error.HTTPError as e:
        error_body = e.read().decode()
        logger.error("API HTTP error %s: %s", e.code, error_body)
        return {"status": "error", "http_status": e.code, "detail": error_body}
    except urllib.error.URLError as e:
        logger.error("API connection error: %s", str(e))
        return {"status": "error", "detail": str(e)}


def lambda_handler(event, context):
    """
    Entry point. Processes one or more SQS records in the batch.
    """
    logger.info("Received event: %s", json.dumps(event))

    results = []

    for record in event.get("Records", []):
        message_id = record.get("messageId", "unknown")
        try:
            body = json.loads(record["body"])
        except (json.JSONDecodeError, KeyError) as exc:
            logger.error("Failed to parse SQS message %s: %s", message_id, exc)
            results.append({"messageId": message_id, "status": "parse_error", "detail": str(exc)})
            continue

        bucket_name = body.get("bucket_name")
        file_name = body.get("file_name")

        if not bucket_name or not file_name:
            msg = "SQS message missing 'bucket_name' or 'file_name'"
            logger.error("Message %s: %s", message_id, msg)
            results.append({"messageId": message_id, "status": "validation_error", "detail": msg})
            continue

        logger.info(
            "Processing message %s — bucket=%s, file=%s",
            message_id, bucket_name, file_name
        )

        result = call_file_info_api(bucket_name, file_name)
        results.append({"messageId": message_id, **result})

    logger.info("Processed %d message(s): %s", len(results), json.dumps(results))
    return {"batchItemFailures": [], "results": results}
