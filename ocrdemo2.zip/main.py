from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import boto3
import os
import json
import mimetypes
from botocore.exceptions import ClientError

app = FastAPI(title="S3 File Info API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

AWS_ENDPOINT_URL = os.getenv("AWS_ENDPOINT_URL", "http://localstack:4566")
AWS_REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")

def get_s3_client():
    return boto3.client(
        "s3",
        endpoint_url=AWS_ENDPOINT_URL,
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID", "test"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY", "test"),
        region_name=AWS_REGION,
    )


class FileInfoRequest(BaseModel):
    bucket_name: str
    file_name: str


class FileInfoResponse(BaseModel):
    bucket_name: str
    file_name: str
    file_size_bytes: int
    file_size_human: str
    content_type: str
    last_modified: str
    etag: str
    status: str = "success"


def human_readable_size(size_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.2f} PB"


@app.get("/health")
def health():
    return {"status": "healthy", "service": "file-info-api"}


@app.post("/file-info", response_model=FileInfoResponse)
def get_file_info(request: FileInfoRequest):
    """
    Accepts a bucket name and file name, returns size and content type.
    """
    s3 = get_s3_client()
    try:
        response = s3.head_object(Bucket=request.bucket_name, Key=request.file_name)
    except ClientError as e:
        code = e.response["Error"]["Code"]
        if code in ("404", "NoSuchKey"):
            raise HTTPException(status_code=404, detail=f"File '{request.file_name}' not found in bucket '{request.bucket_name}'")
        elif code == "NoSuchBucket":
            raise HTTPException(status_code=404, detail=f"Bucket '{request.bucket_name}' does not exist")
        else:
            raise HTTPException(status_code=500, detail=f"AWS error: {str(e)}")

    size = response.get("ContentLength", 0)
    content_type = response.get("ContentType", "application/octet-stream")

    # Fallback: guess from file extension if generic
    if content_type == "application/octet-stream":
        guessed, _ = mimetypes.guess_type(request.file_name)
        if guessed:
            content_type = guessed

    last_modified = response.get("LastModified")
    last_modified_str = last_modified.isoformat() if last_modified else "unknown"
    etag = response.get("ETag", "").strip('"')

    return FileInfoResponse(
        bucket_name=request.bucket_name,
        file_name=request.file_name,
        file_size_bytes=size,
        file_size_human=human_readable_size(size),
        content_type=content_type,
        last_modified=last_modified_str,
        etag=etag,
    )


@app.get("/buckets")
def list_buckets():
    """List all S3 buckets (for the frontend picker)."""
    s3 = get_s3_client()
    try:
        response = s3.list_buckets()
        buckets = [b["Name"] for b in response.get("Buckets", [])]
        return {"buckets": buckets}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/buckets/{bucket_name}/files")
def list_files(bucket_name: str):
    """List files in a bucket."""
    s3 = get_s3_client()
    try:
        response = s3.list_objects_v2(Bucket=bucket_name)
        files = [obj["Key"] for obj in response.get("Contents", [])]
        return {"bucket": bucket_name, "files": files}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=str(e))


class EnqueueRequest(BaseModel):
    bucket_name: str
    file_name: str


@app.post("/enqueue")
def enqueue_file(request: EnqueueRequest):
    """
    Send an SQS message that will trigger the Lambda to call this API.
    """
    sqs = boto3.client(
        "sqs",
        endpoint_url=AWS_ENDPOINT_URL,
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID", "test"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY", "test"),
        region_name=AWS_REGION,
    )
    queue_name = os.getenv("SQS_QUEUE_NAME", "file-processing-queue")
    try:
        q = sqs.get_queue_url(QueueName=queue_name)
        queue_url = q["QueueUrl"]
        msg = json.dumps({"bucket_name": request.bucket_name, "file_name": request.file_name})
        resp = sqs.send_message(QueueUrl=queue_url, MessageBody=msg)
        return {"message_id": resp.get("MessageId"), "status": "queued"}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/presigned-upload")
def get_presigned_upload_url(request: FileInfoRequest):
    """Generate a presigned URL for direct browser → S3 upload."""
    s3 = get_s3_client()
    try:
        url = s3.generate_presigned_url(
            "put_object",
            Params={"Bucket": request.bucket_name, "Key": request.file_name},
            ExpiresIn=3600,
        )
        return {"upload_url": url, "bucket": request.bucket_name, "key": request.file_name}
    except ClientError as e:
        raise HTTPException(status_code=500, detail=str(e))
