#!/bin/sh
set -e

ENDPOINT="http://localstack:4566"
REGION="us-east-1"
BUCKET="documents-bucket"
QUEUE="file-processing-queue"
LAMBDA_NAME="file-processor"
API_URL="http://file-info-api:8000"

echo "=============================================="
echo "  LocalStack Resource Setup"
echo "=============================================="

alias aws="aws --endpoint-url=$ENDPOINT --region=$REGION"

echo ""
echo ">>> Waiting for LocalStack to be ready..."
until aws s3 ls > /dev/null 2>&1; do
  echo "    Still waiting..."
  sleep 3
done
echo "    LocalStack is ready!"

# ── S3 Bucket ───────────────────────────────────────────────────────────────
echo ""
echo ">>> Creating S3 bucket: $BUCKET"
aws s3 mb "s3://$BUCKET" 2>/dev/null || echo "    Bucket already exists"

# Enable CORS on the bucket so the browser can upload directly
aws s3api put-bucket-cors \
  --bucket "$BUCKET" \
  --cors-configuration '{
    "CORSRules": [{
      "AllowedOrigins": ["*"],
      "AllowedMethods": ["GET","PUT","POST","DELETE","HEAD"],
      "AllowedHeaders": ["*"],
      "ExposeHeaders": ["ETag"]
    }]
  }'
echo "    CORS configured."

# ── SQS Queue ────────────────────────────────────────────────────────────────
echo ""
echo ">>> Creating SQS queue: $QUEUE"
QUEUE_URL=$(aws sqs create-queue \
  --queue-name "$QUEUE" \
  --attributes VisibilityTimeout=60 \
  --query "QueueUrl" \
  --output text)
echo "    Queue URL: $QUEUE_URL"

QUEUE_ARN=$(aws sqs get-queue-attributes \
  --queue-url "$QUEUE_URL" \
  --attribute-names QueueArn \
  --query "Attributes.QueueArn" \
  --output text)
echo "    Queue ARN: $QUEUE_ARN"

# ── IAM Role for Lambda ──────────────────────────────────────────────────────
echo ""
echo ">>> Creating IAM role for Lambda..."
aws iam create-role \
  --role-name lambda-execution-role \
  --assume-role-policy-document '{
    "Version":"2012-10-17",
    "Statement":[{
      "Effect":"Allow",
      "Principal":{"Service":"lambda.amazonaws.com"},
      "Action":"sts:AssumeRole"
    }]
  }' 2>/dev/null || echo "    Role already exists"

aws iam attach-role-policy \
  --role-name lambda-execution-role \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole \
  2>/dev/null || true

aws iam attach-role-policy \
  --role-name lambda-execution-role \
  --policy-arn arn:aws:iam::aws:policy/AmazonSQSFullAccess \
  2>/dev/null || true

ROLE_ARN="arn:aws:iam::000000000000:role/lambda-execution-role"
echo "    Role ARN: $ROLE_ARN"

# ── Package Lambda ───────────────────────────────────────────────────────────
echo ""
echo ">>> Packaging Lambda function..."
cd /lambda
zip -j /tmp/lambda.zip lambda_function.py
echo "    Packaged to /tmp/lambda.zip"

# ── Deploy Lambda ────────────────────────────────────────────────────────────
echo ""
echo ">>> Deploying Lambda: $LAMBDA_NAME"
aws lambda delete-function --function-name "$LAMBDA_NAME" 2>/dev/null || true

aws lambda create-function \
  --function-name "$LAMBDA_NAME" \
  --runtime python3.11 \
  --handler lambda_function.lambda_handler \
  --role "$ROLE_ARN" \
  --zip-file fileb:///tmp/lambda.zip \
  --environment "Variables={FILE_INFO_API_URL=$API_URL}" \
  --timeout 30 \
  --memory-size 256

echo "    Lambda deployed!"

# ── SQS → Lambda Event Source Mapping ───────────────────────────────────────
echo ""
echo ">>> Mapping SQS → Lambda trigger..."
aws lambda create-event-source-mapping \
  --function-name "$LAMBDA_NAME" \
  --event-source-arn "$QUEUE_ARN" \
  --batch-size 5 \
  --enabled 2>/dev/null || echo "    Event source mapping already exists"

echo ""
echo "=============================================="
echo "  Setup complete!"
echo "  Bucket : $BUCKET"
echo "  Queue  : $QUEUE_URL"
echo "  Lambda : $LAMBDA_NAME"
echo "  API    : $API_URL"
echo "=============================================="

# ── Upload a sample test file ────────────────────────────────────────────────
echo ""
echo ">>> Uploading sample test file..."
echo "Hello from LocalStack! This is a test document." > /tmp/sample.txt
aws s3 cp /tmp/sample.txt "s3://$BUCKET/sample.txt"
echo "    Uploaded sample.txt"

echo ""
echo ">>> Sending a test SQS message to trigger the Lambda..."
aws sqs send-message \
  --queue-url "$QUEUE_URL" \
  --message-body '{"bucket_name":"documents-bucket","file_name":"sample.txt"}'
echo "    Test message sent!"

echo ""
echo "All done. Visit http://localhost:3000 to use the upload form."
