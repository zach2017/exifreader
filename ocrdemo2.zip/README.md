# DocVault — LocalStack S3 + Lambda + SQS Demo

A full local-cloud demo stack that lets you upload files to S3 (via LocalStack),
query file metadata through a FastAPI service, and trigger a Lambda via SQS messages.

```
┌─────────────────────────────────────────────────────────────────┐
│                         Docker Network                          │
│                                                                 │
│  ┌──────────┐   ①PUT    ┌─────────────┐                        │
│  │  Browser │──────────▶│  LocalStack │ (S3 / SQS / Lambda)    │
│  │(Tailwind)│   ③POST   │             │                        │
│  │ :3000    │──────────▶│  FastAPI    │◀─── Lambda calls API   │
│  └──────────┘           │  :8000      │                        │
│       │                 └─────────────┘                        │
│       │  ②SQS message        │                                 │
│       └──────────────────────▶ SQS Queue → Lambda trigger      │
└─────────────────────────────────────────────────────────────────┘
```

## Flow

1. **Upload** — browser sends file directly to LocalStack S3 via presigned PUT URL.
2. **Enqueue** — browser POSTs to `/api/enqueue`; FastAPI sends an SQS message containing `{bucket_name, file_name}`.
3. **Lambda trigger** — LocalStack polls SQS and invokes the Lambda with the batch of messages.
4. **Lambda → API** — Lambda POSTs to `http://file-info-api:8000/file-info`.
5. **API → S3** — FastAPI calls `s3.head_object(...)` and returns size + content type.
6. **Inspect** — you can also call the API directly from the "Inspect File" panel.

## Prerequisites

- Docker Desktop (or Docker Engine + Compose v2)
- Port 3000, 4566, 8000 free on localhost

## Quick Start

```bash
# 1. Clone / unzip this project, then:
cd s3-lambda-app

# 2. Build and start everything
docker compose up --build

# Wait ~30 seconds for LocalStack + setup to complete.
# The init container will:
#   - Create the S3 bucket  (documents-bucket)
#   - Create the SQS queue  (file-processing-queue)
#   - Deploy the Lambda     (file-processor)
#   - Wire SQS → Lambda
#   - Upload a sample file  (sample.txt)
#   - Send a test SQS message

# 3. Open the UI
open http://localhost:3000

# 4. Open the API docs
open http://localhost:8000/docs
```

## Endpoints (FastAPI)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check |
| POST | `/file-info` | Get size + type for a file |
| GET | `/buckets` | List all S3 buckets |
| GET | `/buckets/{name}/files` | List files in a bucket |
| POST | `/presigned-upload` | Get a presigned S3 PUT URL |
| POST | `/enqueue` | Send an SQS message (triggers Lambda) |

## SQS Message Format

```json
{
  "bucket_name": "documents-bucket",
  "file_name": "path/to/my-file.pdf"
}
```

## Useful Commands

```bash
# Tail Lambda logs
docker exec localstack awslocal logs tail /aws/lambda/file-processor --follow

# List bucket contents
docker exec localstack awslocal s3 ls s3://documents-bucket

# Send a manual SQS message
docker exec localstack awslocal sqs send-message \
  --queue-url http://localhost:4566/000000000000/file-processing-queue \
  --message-body '{"bucket_name":"documents-bucket","file_name":"sample.txt"}'

# View Lambda list
docker exec localstack awslocal lambda list-functions

# Stop everything
docker compose down -v
```

## Project Structure

```
s3-lambda-app/
├── docker-compose.yml        # Orchestration
├── api/
│   ├── Dockerfile
│   ├── main.py               # FastAPI service
│   └── requirements.txt
├── lambda/
│   └── lambda_function.py    # SQS-triggered Lambda
├── frontend/
│   ├── index.html            # Tailwind upload UI
│   └── nginx.conf            # Reverse proxy config
└── scripts/
    └── setup.sh              # LocalStack resource init
```
